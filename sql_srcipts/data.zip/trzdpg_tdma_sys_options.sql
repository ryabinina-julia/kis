insert into tdma.sys_options (option_name, option_value) values ('ENABLE_CLEAR', '1');
insert into tdma.sys_options (option_name, option_value) values ('SKPI_DEEP_DAYS', '1');
insert into tdma.sys_options (option_name, option_value) values ('KSAU_DEEP_DAYS', '1');
insert into tdma.sys_options (option_name, option_value) values ('PPSS_DEEP_DAYS', '1');
insert into tdma.sys_options (option_name, option_value) values ('TDMA_DEEP_DAYS', '4');
insert into tdma.sys_options (option_name, option_value) values ('NO_VAG_DEEP_HOURS', '1');
insert into tdma.sys_options (option_name, option_value) values ('OUT_DAYS', '1');
